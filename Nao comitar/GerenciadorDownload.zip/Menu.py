from datetime import date
"""Solicita a opção do Programa Principal"""
"""Funções do Menu!!!"""

def menu():
  print("Gerenciador de Downloads", date.today())
  print('-'*35)
  print(''' Opções:
1- Cadastrar banda larga;
2- Computadores;
3- Recursos;
4- Jobs;
0- Sair do programa;''')
  print('-'*35)

def menuComputador():
  print('''
  1 - Cadastrar computador;
  2 - Listar Computadores
  3 - Exportar computadores
  4 - Importar computadores
  0 - Voltar para menu principal''')
  
def menuRecursos():
  print('''
  1 - Cadastrar recursos
  2 - Listar recursos
  3 - Exportar recursos
  4 - Importar recursos
  0 - Voltar para menu principal''')

def menuJobs():
  print('''
  1 - Cadastrar Jobs
  2 - Listar Jobs
  3 - Exportar Jobs
  4 - Importar Jobs
  0 - Voltar para menu principal''')

def clear():
  import os
  if os.name == 'nt':
    os.system('cls')
  else:
    os.system('clear')
